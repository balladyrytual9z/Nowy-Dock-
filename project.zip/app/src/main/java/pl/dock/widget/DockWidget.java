package pl.dock.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;
import java.util.Locale;

public class DockWidget extends AppWidgetProvider {

    private static final int[] TOP_IDS = {R.id.app1, R.id.app2, R.id.app3};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        StatusService.start(context);
        RemoteViews rv = build(context);
        for (int id : ids) {
            manager.updateAppWidget(id, rv);
        }
    }

    public static void updateAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        int[] ids = m.getAppWidgetIds(new ComponentName(context, DockWidget.class));
        if (ids == null || ids.length == 0) return;
        m.updateAppWidget(ids, build(context));
    }

    private static PendingIntent launchIntent(Context c, AppEntry e, int req) {
        Intent i = new Intent(c, LaunchReceiver.class);
        i.setData(Uri.parse("dock://launch/" + e.key()));
        i.putExtra("id", e.id);
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static RemoteViews build(Context c) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dock_widget);

        // wygląd: styl + tryb dzienny/nocny
        boolean night = Look.night(c);
        boolean glass = "glass".equals(Prefs.style(c));
        int fg = night ? 0xFFFFFFFF : 0xFF12151C;
        int dim = (fg & 0x00FFFFFF) | 0x55000000;
        rv.setInt(R.id.root, "setBackgroundResource", Look.bg(glass, night));
        rv.setTextColor(R.id.clock, fg);
        rv.setTextColor(R.id.volt, fg);
        rv.setInt(R.id.wifi, "setColorFilter", wifiConnected(c) ? fg : dim);
        rv.setInt(R.id.bt, "setColorFilter", bluetoothOn() ? fg : dim);
        rv.setInt(R.id.battery, "setColorFilter", fg);

        // 3 górne aplikacje (wg ostatniego / najczęstszego użycia)
        List<AppEntry> top = Prefs.top(c, 3);
        for (int i = 0; i < TOP_IDS.length; i++) {
            if (i < top.size()) {
                AppEntry e = top.get(i);
                rv.setViewVisibility(TOP_IDS[i], View.VISIBLE);
                rv.setImageViewBitmap(TOP_IDS[i], Icons.forEntry(c, e));
                rv.setOnClickPendingIntent(TOP_IDS[i], launchIntent(c, e, i));
            } else {
                rv.setViewVisibility(TOP_IDS[i], View.GONE);
            }
        }

        // CarPlay: zawsze na samym dole
        AppEntry cp = Prefs.carplay(c);
        rv.setImageViewBitmap(R.id.carplay, Icons.forEntry(c, cp));
        rv.setOnClickPendingIntent(R.id.carplay, launchIntent(c, cp, 10));

        // klik w zegar/statusy = ustawienia
        Intent cfg = new Intent(c, ConfigActivity.class);
        cfg.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        rv.setOnClickPendingIntent(R.id.header, PendingIntent.getActivity(
                c, 20, cfg, PendingIntent.FLAG_UPDATE_CURRENT));

        // napięcie (opcjonalnie)
        if (Prefs.showVoltage(c)) {
            rv.setViewVisibility(R.id.power_row, View.VISIBLE);
            rv.setTextViewText(R.id.volt, voltage(c));
        } else {
            rv.setViewVisibility(R.id.power_row, View.GONE);
        }
        return rv;
    }

    private static boolean bluetoothOn() {
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            return a != null && a.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private static boolean wifiConnected(Context c) {
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return false;
            ConnectivityManager cm = (ConnectivityManager)
                    c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    private static String voltage(Context c) {
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int mv = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
            if (mv <= 0) return "-- V";
            float v = mv > 100 ? mv / 1000f : mv;
            return String.format(new Locale("pl"), "%.2f V", v);
        } catch (Exception e) {
            return "-- V";
        }
    }
}
