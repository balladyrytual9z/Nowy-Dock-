package pl.dock.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

// Widżet nie rozpoznaje podwójnego dotknięcia sam, więc liczymy odstęp między dwoma kliknięciami
public class HeaderReceiver extends BroadcastReceiver {
    private static long last = 0;
    private static final long DOUBLE_MS = 500;

    @Override
    public void onReceive(Context c, Intent i) {
        long now = SystemClock.elapsedRealtime();
        if (last != 0 && now - last <= DOUBLE_MS) {
            last = 0;
            Intent open = new Intent(c, ConnectivityActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                c.startActivity(open);
            } catch (Throwable ignored) {
            }
        } else {
            last = now;
        }
    }
}
