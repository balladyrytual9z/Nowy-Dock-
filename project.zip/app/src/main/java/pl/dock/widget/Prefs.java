package pl.dock.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Prefs {
    static final String[] SEED = {"com.waze", "com.brave.browser", "com.android.dialer"};

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("dock", Context.MODE_PRIVATE);
    }

    // ---------- lista aplikacji (dowolna liczba) ----------
    public static List<AppEntry> apps(Context c) {
        SharedPreferences s = sp(c);
        List<AppEntry> out = new ArrayList<AppEntry>();
        if (!s.contains("apps")) {
            PackageManager pm = c.getPackageManager();
            long t = System.currentTimeMillis();
            for (String p : SEED) {
                if (pm.getLaunchIntentForPackage(p) != null) {
                    AppEntry e = new AppEntry();
                    e.id = t++;
                    e.pkg = p;
                    out.add(e);
                }
            }
            saveApps(c, out);
            return out;
        }
        try {
            JSONArray a = new JSONArray(s.getString("apps", "[]"));
            for (int i = 0; i < a.length(); i++) {
                out.add(AppEntry.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    public static void saveApps(Context c, List<AppEntry> list) {
        JSONArray a = new JSONArray();
        for (AppEntry e : list) a.put(e.toJson());
        sp(c).edit().putString("apps", a.toString()).apply();
    }

    public static AppEntry add(Context c, String pkg) {
        List<AppEntry> l = apps(c);
        AppEntry e = new AppEntry();
        e.id = System.currentTimeMillis();
        e.pkg = pkg;
        l.add(e);
        saveApps(c, l);
        return e;
    }

    public static void remove(Context c, long id) {
        List<AppEntry> l = apps(c);
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == id) {
                Icons.file(c, l.get(i)).delete();
                l.remove(i);
                break;
            }
        }
        saveApps(c, l);
    }

    // zapis zmienionego wpisu (zwykłego albo CarPlay)
    public static void persist(Context c, AppEntry e) {
        if (e.id == 0) {
            saveCarplay(c, e);
            return;
        }
        List<AppEntry> l = apps(c);
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == e.id) {
                l.set(i, e);
                break;
            }
        }
        saveApps(c, l);
    }

    // ---------- CarPlay (zawsze na dole) ----------
    public static AppEntry carplay(Context c) {
        try {
            String s = sp(c).getString("cp", null);
            if (s != null) {
                AppEntry e = AppEntry.fromJson(new JSONObject(s));
                e.id = 0;
                return e;
            }
        } catch (Exception ignored) {
        }
        return new AppEntry();
    }

    public static void saveCarplay(Context c, AppEntry e) {
        e.id = 0;
        sp(c).edit().putString("cp", e.toJson().toString()).apply();
    }

    // ---------- użycie ----------
    public static void recordUse(Context c, long id) {
        List<AppEntry> l = apps(c);
        for (AppEntry e : l) {
            if (e.id == id) {
                e.count++;
                e.last = System.currentTimeMillis();
                break;
            }
        }
        saveApps(c, l);
    }

    public static void resetStats(Context c) {
        List<AppEntry> l = apps(c);
        for (AppEntry e : l) {
            e.count = 0;
            e.last = 0;
        }
        saveApps(c, l);
    }

    // 3 górne aplikacje wg wybranej kolejności
    public static List<AppEntry> top(Context c, int n) {
        PackageManager pm = c.getPackageManager();
        List<AppEntry> ok = new ArrayList<AppEntry>();
        for (AppEntry e : apps(c)) {
            if (e.pkg.length() > 0 && pm.getLaunchIntentForPackage(e.pkg) != null) ok.add(e);
        }
        final boolean byCount = "count".equals(sortMode(c));
        Collections.sort(ok, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                if (byCount) {
                    int x = Integer.compare(b.count, a.count);
                    if (x != 0) return x;
                }
                return Long.compare(b.last, a.last);
            }
        });
        return ok.size() > n ? new ArrayList<AppEntry>(ok.subList(0, n)) : ok;
    }

    // ---------- ustawienia ----------
    public static String sortMode(Context c) {
        return sp(c).getString("sort", "last");   // last | count
    }

    public static void setSortMode(Context c, String v) {
        sp(c).edit().putString("sort", v).apply();
    }

    public static String style(Context c) {
        return sp(c).getString("style", "classic");   // classic | glass
    }

    public static void setStyle(Context c, String v) {
        sp(c).edit().putString("style", v).apply();
    }

    public static boolean followSystem(Context c) {
        return sp(c).getBoolean("follow", false);
    }

    public static void setFollowSystem(Context c, boolean v) {
        sp(c).edit().putBoolean("follow", v).apply();
    }

    public static boolean night(Context c) {
        return sp(c).getBoolean("night", true);
    }

    public static void setNight(Context c, boolean v) {
        sp(c).edit().putBoolean("night", v).apply();
    }

    public static boolean showVoltage(Context c) {
        return sp(c).getBoolean("voltage", false);
    }

    public static void setShowVoltage(Context c, boolean v) {
        sp(c).edit().putBoolean("voltage", v).apply();
    }
}
