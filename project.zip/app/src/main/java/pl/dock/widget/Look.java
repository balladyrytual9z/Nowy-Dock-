package pl.dock.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

public class Look {

    // Czy teraz jest tryb nocny (ręcznie albo wg systemu)
    public static boolean night(Context c) {
        if (Prefs.followSystem(c)) {
            int m = Resources.getSystem().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK;
            return m == Configuration.UI_MODE_NIGHT_YES;
        }
        String m = Prefs.mode(c);
        if ("time".equals(m)) {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            int now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE);
            int st = Prefs.nightStart(c);
            int en = Prefs.nightEnd(c);
            if (st > en) return now >= st || now < en;
            return now >= st && now < en;
        }
        return "night".equals(m);
    }

    public static int bg(boolean glass, boolean night) {
        if (glass) return night ? R.drawable.bg_glass_night : R.drawable.bg_glass_day;
        return night ? R.drawable.bg_classic_night : R.drawable.bg_classic_day;
    }

    // Kolory ekranu ustawień (styl CarPlay)
    public static class Pal {
        public int bg, card, text, sub, accent, sep;
    }

    public static Pal pal(boolean night) {
        Pal p = new Pal();
        if (night) {
            p.bg = 0xFF070B14;
            p.card = 0xFF141B2B;
            p.text = 0xFFFFFFFF;
            p.sub = 0xFF8E9BB3;
            p.accent = 0xFF0A84FF;
            p.sep = 0xFF263149;
        } else {
            p.bg = 0xFFE8EDF5;
            p.card = 0xFFFFFFFF;
            p.text = 0xFF10131A;
            p.sub = 0xFF6B7686;
            p.accent = 0xFF0A6CFF;
            p.sep = 0xFFE1E6EE;
        }
        return p;
    }
}
