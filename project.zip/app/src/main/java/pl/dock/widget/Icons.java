package pl.dock.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.io.FileOutputStream;

public class Icons {
    static final int S = 128;

    static File file(Context c, AppEntry e) {
        return new File(c.getFilesDir(), "icon_" + e.key() + ".png");
    }

    // ---------------------------------------------------------------- ikony aplikacji

    public static Bitmap forEntry(Context c, AppEntry e) {
        try {
            if ("builtin".equals(e.mode) && e.iconPkg.length() > 0) {
                return compose(c, BuiltinIcons.render(e.iconPkg, S), true);
            }
            if (e.id == 0 && "default".equals(e.mode) && e.pkg.length() == 0) {
                return compose(c, BuiltinIcons.render("carplay", S), true);
            }
            if ("file".equals(e.mode)) {
                Bitmap f = BitmapFactory.decodeFile(file(c, e).getAbsolutePath());
                if (f != null) return compose(c, f, true);
            } else if ("app".equals(e.mode) && e.iconPkg.length() > 0) {
                return compose(c, drawableToBitmap(
                        c.getPackageManager().getApplicationIcon(e.iconPkg)), false);
            }
            if (e.pkg.length() > 0) {
                return compose(c, drawableToBitmap(
                        c.getPackageManager().getApplicationIcon(e.pkg)), false);
            }
        } catch (Throwable ignored) {
        }
        return compose(c, null, true);
    }

    public static Bitmap forPackage(Context c, String pkg) {
        try {
            return compose(c, drawableToBitmap(c.getPackageManager().getApplicationIcon(pkg)), false);
        } catch (Throwable e) {
            return compose(c, null, true);
        }
    }

    // wbudowana ikona z ramką (do wyboru w ustawieniach)
    public static Bitmap builtin(Context c, String id) {
        return compose(c, BuiltinIcons.render(id, S), true);
    }

    static Bitmap drawableToBitmap(Drawable d) {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, S, S);
        d.draw(cv);
        return b;
    }

    // zaokrąglona ikona bez ramki
    static Bitmap rounded(Bitmap raw) {
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas oc = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = S * 0.225f;
        if (raw != null) {
            Bitmap sc = Bitmap.createScaledBitmap(raw, S, S, true);
            p.setShader(new BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        } else {
            p.setColor(0xFF2A3344);
        }
        oc.drawRoundRect(new RectF(0, 0, S, S), r, r, p);
        return out;
    }

    // Ramka jak w CarPlay: ciemny kafelek z cienkim jasnym pierścieniem.
    // tile = true: obraz jest już kafelkiem (wbudowany / własny z pliku) – tylko pierścień.
    // tile = false: ikona aplikacji; w trybie "carplay" ląduje wcięta w ciemnym kafelku.
    static Bitmap compose(Context c, Bitmap raw, boolean tile) {
        String fm = Prefs.frame(c);
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float r = S * 0.225f;
        if (raw != null && "carplay".equals(fm) && !tile) {
            p.setShader(new LinearGradient(0, 0, 0, S, 0xFF2E2E31, 0xFF19191B,
                    Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(0, 0, S, S), r, r, p);
            p.setShader(null);
            float pad = S * 0.11f;
            cv.drawBitmap(rounded(raw), null, new RectF(pad, pad, S - pad, S - pad), p);
        } else {
            cv.drawBitmap(rounded(raw), 0, 0, null);
        }
        if (!"none".equals(fm)) {
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            float w = S * 0.03f;
            ring.setStrokeWidth(w);
            ring.setColor(0x66FFFFFF);
            cv.drawRoundRect(new RectF(w / 2, w / 2, S - w / 2, S - w / 2),
                    r - w / 2, r - w / 2, ring);
        }
        return out;
    }

    // ---------------------------------------------------------------- ikony statusu

    // Ikona wektorowa w podanym kolorze, wyśrodkowana pod względem widocznej zawartości
    public static Bitmap vector(Context c, int resId, int size, int color) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        try {
            Drawable d = c.getDrawable(resId).mutate();
            d.setBounds(0, 0, size, size);
            d.setColorFilter(color, PorterDuff.Mode.SRC_IN);
            d.draw(new Canvas(b));
        } catch (Throwable ignored) {
        }
        return centered(b);
    }

    // Tethering (hotspot) jak w iPhonie: dwa spięte ogniwa łańcucha; slash = wyłączony
    public static Bitmap tether(int size, int color, boolean slash) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float s = size;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.095f);
        p.setColor(color);
        float w = s * 0.50f;
        float h = s * 0.30f;
        cv.save();
        cv.rotate(-30, s / 2, s / 2);
        cv.drawRoundRect(new RectF(s * 0.08f, s * 0.5f - h / 2, s * 0.08f + w, s * 0.5f + h / 2),
                h / 2, h / 2, p);
        cv.drawRoundRect(new RectF(s * 0.42f, s * 0.5f - h / 2, s * 0.42f + w, s * 0.5f + h / 2),
                h / 2, h / 2, p);
        cv.restore();
        if (slash) {
            Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
            clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            clear.setStyle(Paint.Style.STROKE);
            clear.setStrokeWidth(s * 0.21f);
            cv.drawLine(s * 0.16f, s * 0.16f, s * 0.84f, s * 0.84f, clear);
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeWidth(s * 0.095f);
            line.setColor(color);
            cv.drawLine(s * 0.16f, s * 0.16f, s * 0.84f, s * 0.84f, line);
        }
        return centered(b);
    }

    // Przesuwa zawartość tak, by jej środek leżał dokładnie w środku bitmapy
    static Bitmap centered(Bitmap b) {
        try {
            int w = b.getWidth();
            int h = b.getHeight();
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    if ((px[y * w + x] >>> 24) > 16) {
                        if (x < minX) minX = x;
                        if (x > maxX) maxX = x;
                        if (y < minY) minY = y;
                        if (y > maxY) maxY = y;
                    }
                }
            }
            if (maxX < 0) return b;
            float dx = w / 2f - (minX + maxX + 1) / 2f;
            float dy = h / 2f - (minY + maxY + 1) / 2f;
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            new Canvas(out).drawBitmap(b, dx, dy, null);
            return out;
        } catch (Throwable t) {
            return b;
        }
    }

    // ---------------------------------------------------------------- własny obraz z pliku

    public static boolean saveFromStream(Context c, AppEntry e, java.io.InputStream in1,
                                         java.io.InputStream in2) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in1, null, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(in2, null, o2);
            if (bmp == null) return false;
            int side = Math.min(bmp.getWidth(), bmp.getHeight());
            Bitmap sq = Bitmap.createBitmap(bmp,
                    (bmp.getWidth() - side) / 2, (bmp.getHeight() - side) / 2, side, side);
            Bitmap fin = Bitmap.createScaledBitmap(sq, 256, 256, true);
            FileOutputStream fo = new FileOutputStream(file(c, e));
            fin.compress(Bitmap.CompressFormat.PNG, 100, fo);
            fo.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
