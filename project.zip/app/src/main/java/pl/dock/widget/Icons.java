package pl.dock.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.io.FileOutputStream;

public class Icons {
    static final int S = 128;

    static File file(Context c, AppEntry e) {
        return new File(c.getFilesDir(), "icon_" + e.key() + ".png");
    }

    // Gotowa, zaokrąglona ikona dla wpisu
    public static Bitmap forEntry(Context c, AppEntry e) {
        Bitmap raw = null;
        try {
            if ("file".equals(e.mode)) {
                raw = BitmapFactory.decodeFile(file(c, e).getAbsolutePath());
            } else if ("app".equals(e.mode) && e.iconPkg.length() > 0) {
                raw = drawableToBitmap(c.getPackageManager().getApplicationIcon(e.iconPkg));
            }
            if (raw == null && e.pkg.length() > 0) {
                raw = drawableToBitmap(c.getPackageManager().getApplicationIcon(e.pkg));
            }
        } catch (Exception ignored) {
        }
        return rounded(raw);
    }

    public static Bitmap forPackage(Context c, String pkg) {
        try {
            return rounded(drawableToBitmap(c.getPackageManager().getApplicationIcon(pkg)));
        } catch (Exception e) {
            return rounded(null);
        }
    }

    static Bitmap drawableToBitmap(Drawable d) {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, S, S);
        d.draw(cv);
        return b;
    }

    static Bitmap rounded(Bitmap raw) {
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas oc = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = S * 0.225f;
        if (raw != null) {
            Bitmap sc = Bitmap.createScaledBitmap(raw, S, S, true);
            p.setShader(new BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        } else {
            p.setColor(Color.parseColor("#2A3344"));
        }
        oc.drawRoundRect(new RectF(0, 0, S, S), r, r, p);
        return out;
    }

    // Własna ikona z pliku: kadr do kwadratu, 256 px
    public static boolean saveFromStream(Context c, AppEntry e, java.io.InputStream in1,
                                         java.io.InputStream in2) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in1, null, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(in2, null, o2);
            if (bmp == null) return false;
            int side = Math.min(bmp.getWidth(), bmp.getHeight());
            Bitmap sq = Bitmap.createBitmap(bmp,
                    (bmp.getWidth() - side) / 2, (bmp.getHeight() - side) / 2, side, side);
            Bitmap fin = Bitmap.createScaledBitmap(sq, 256, 256, true);
            FileOutputStream fo = new FileOutputStream(file(c, e));
            fin.compress(Bitmap.CompressFormat.PNG, 100, fo);
            fo.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
