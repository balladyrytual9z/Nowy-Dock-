package pl.dock.widget;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

// Menu łączności (podwójne dotknięcie paska): WiFi, Bluetooth, tethering
public class ConnectivityActivity extends Activity {

    private Look.Pal p;
    private boolean night;
    private final FrameLayout[] circle = new FrameLayout[3];
    private final ImageView[] icon = new ImageView[3];
    private final TextView[] sub = new TextView[3];
    private final Handler h = new Handler(Looper.getMainLooper());
    private BroadcastReceiver rc;
    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            update();
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private GradientDrawable shape(int color, int radiusDp, boolean oval) {
        GradientDrawable g = new GradientDrawable();
        if (oval) g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        if (!oval) g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle b) {
        night = Look.night(this);
        setTheme(android.R.style.Theme_Translucent_NoTitleBar);
        super.onCreate(b);
        p = Look.pal(night);
        build();
        update();
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xB0000000);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(p.card, 30, false));
        card.setPadding(dp(24), dp(20), dp(24), dp(12));
        card.setClickable(true);
        int w = Math.min(getResources().getDisplayMetrics().widthPixels - dp(48), dp(560));
        root.addView(card, new FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        TextView title = tv("Łączność", 24, p.text, true);
        title.setPadding(0, 0, 0, dp(16));
        card.addView(title);

        LinearLayout tiles = new LinearLayout(this);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = {"Wi-Fi", "Bluetooth", "Hotspot"};
        for (int i = 0; i < 3; i++) {
            tiles.addView(tile(i, labels[i]),
                    new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        card.addView(tiles);

        TextView settings = tv("Ustawienia Docka", 18, p.accent, false);
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(0, dp(22), 0, dp(14));
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ConnectivityActivity.this, ConfigActivity.class));
                finish();
            }
        });
        card.addView(settings);

        setContentView(root);
    }

    private View tile(final int i, String label) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);

        FrameLayout c = new FrameLayout(this);
        circle[i] = c;
        ImageView iv = new ImageView(this);
        icon[i] = iv;
        c.addView(iv, new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER));
        t.addView(c, new LinearLayout.LayoutParams(dp(88), dp(88)));
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle(i);
            }
        });

        TextView l = tv(label, 17, p.text, true);
        l.setPadding(0, dp(10), 0, 0);
        t.addView(l);
        TextView s = tv("", 13, p.sub, false);
        sub[i] = s;
        t.addView(s);
        return t;
    }

    private void toggle(int i) {
        if (i == 0) {
            if (!Net.setWifi(this, !Net.wifiEnabled(this))) {
                Toast.makeText(this, "Nie udało się zmienić Wi-Fi", Toast.LENGTH_SHORT).show();
            }
        } else if (i == 1) {
            if (!Net.setBluetooth(!Net.bluetoothOn())) {
                Toast.makeText(this, "Nie udało się zmienić Bluetooth", Toast.LENGTH_SHORT).show();
            }
        } else {
            String r = Net.setTethering(this, !Net.tethering(this));
            if ("settings".equals(r)) {
                Toast.makeText(this, "Hotspotu nie da się przełączyć z aplikacji – "
                        + "otwieram ustawienia systemu", Toast.LENGTH_LONG).show();
            } else if ("fail".equals(r)) {
                Toast.makeText(this, "Nie udało się zmienić hotspotu", Toast.LENGTH_SHORT).show();
            }
        }
        h.postDelayed(refresh, 700);
        h.postDelayed(refresh, 1800);
        h.postDelayed(refresh, 3500);
    }

    private void style(int i, boolean active, Bitmap bmp, String text) {
        int fill = active ? p.accent : (night ? 0xFF3A3A3C : 0xFFD1D1D6);
        GradientDrawable g = shape(fill, 0, true);
        if (!active) g.setStroke(dp(2), night ? 0x66FFFFFF : 0x33000000);
        circle[i].setBackground(g);
        icon[i].setImageBitmap(bmp);
        sub[i].setText(text);
    }

    private void update() {
        boolean wEn = Net.wifiEnabled(this);
        boolean wCon = Net.wifiConnected(this);
        boolean bt = Net.bluetoothOn();
        boolean th = Net.tethering(this);
        int on = 0xFFFFFFFF;
        int off = night ? 0xFFFFFFFF : 0xFF3C3C43;

        style(0, wEn, Icons.vector(this, wEn ? R.drawable.ic_wifi : R.drawable.ic_wifi_off, 128,
                wEn ? on : off), wCon ? "Połączono" : (wEn ? "Włączone" : "Wyłączone"));
        style(1, bt, Icons.vector(this, R.drawable.ic_bt, 128, bt ? on : off),
                bt ? "Włączony" : "Wyłączony");
        style(2, th, Icons.tether(128, th ? on : off, !th), th ? "Włączony" : "Wyłączony");
        DockWidget.updateAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        rc = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                update();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        f.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction("android.net.conn.TETHER_STATE_CHANGED");
        registerReceiver(rc, f);
        update();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (rc != null) unregisterReceiver(rc);
        } catch (Exception ignored) {
        }
        rc = null;
        h.removeCallbacks(refresh);
    }
}
