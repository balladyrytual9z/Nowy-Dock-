package pl.dock.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Obsługuje kliknięcie ikony na widżecie: zlicza użycie i uruchamia aplikację
public class LaunchReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        long id = i.getLongExtra("id", 0);
        String pkg = "";
        if (id == 0) {
            pkg = Prefs.carplay(c).pkg;
        } else {
            for (AppEntry e : Prefs.apps(c)) {
                if (e.id == id) {
                    pkg = e.pkg;
                    break;
                }
            }
            Prefs.recordUse(c, id);
        }
        Intent launch = pkg.length() > 0
                ? c.getPackageManager().getLaunchIntentForPackage(pkg) : null;
        if (launch == null) {
            launch = new Intent(c, ConfigActivity.class);
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(launch);
        } catch (Exception ignored) {
        }
        DockWidget.updateAll(c);
    }
}
